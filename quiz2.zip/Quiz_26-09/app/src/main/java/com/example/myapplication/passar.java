package com.example.myapplication;

public class passar {
    static float ponto = 0;

    public static void setPonto(float ponto) {
        passar.ponto = ponto;
    }

    public static float getPonto() {
        return ponto;
    }
}
